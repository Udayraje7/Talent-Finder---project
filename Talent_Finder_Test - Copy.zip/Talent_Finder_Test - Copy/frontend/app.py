import sys
import os
import streamlit as st
import pandas as pd

# Backend path setup
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Import functions
from backend.text_extraction import extract_text, extract_details
from backend.matching_logic import calculate_scores
from backend.database import init_db, save_scan_result, fetch_history, delete_record, delete_all_records

# Initialize Database
init_db()

# --- 1. PAGE CONFIG ---
st.set_page_config(
    page_title="Talent Finder",
    page_icon="🕵️‍♂️",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# --- 2. CSS STYLING ---
st.markdown("""
    <style>
        /* MAIN BACKGROUND */
        .main {background-color: #0e1117;}
        
        /* FONTS */
        h1, h2, h3, h4 {font-family: 'Segoe UI', sans-serif; color: #ffffff; text-align: center;}
        
        /* 1. METRIC CARDS */
        div[data-testid="stMetric"] {
            background-color: #1a1c24 !important;
            border-left: 5px solid #4facfe;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3); 
            text-align: center;
        }
        div[data-testid="stMetricLabel"] p { color: #b0b0b0 !important; font-size: 14px; font-weight: 600; }
        div[data-testid="stMetricValue"] div { color: #ffffff !important; font-size: 28px; font-weight: 700; }

        /* 2. WINNER BOX CONTAINER */
        .winner-box {
            background: linear-gradient(90deg, #00F260 0%, #0575E6 100%);
            padding: 25px;
            border-radius: 12px;
            margin-top: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.5);
        }
        
        .winner-header {
            color: #ffffff;
            font-size: 20px;
            font-weight: 800;
            margin-bottom: 20px;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            text-shadow: 0px 2px 4px rgba(0,0,0,0.3);
        }

        /* 3. INNER CARDS (CENTERED WITH PROGRESS BAR) */
        .winner-item {
            background-color: rgba(0, 20, 40, 0.6); /* Dark Tint */
            border-radius: 8px;
            padding: 20px;
            margin: 10px 0;
            color: white;
            border: 1px solid rgba(255,255,255,0.1);
            
            /* Center Alignment */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            
            backdrop-filter: blur(4px);
        }
        
        .winner-name { font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 5px; }
        .winner-email { font-size: 13px; color: #e0e0e0; margin-bottom: 10px; }
        
        /* Score Text */
        .winner-score { font-size: 16px; font-weight: 700; color: #76ff03; margin-bottom: 5px; }

        /* PROGRESS BAR STYLES (Winner Box Only) */
        .progress-track {
            width: 60%;
            background-color: rgba(255,255,255,0.15);
            height: 8px;
            border-radius: 4px;
            margin-top: 5px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background-color: #76ff03; /* Neon Green */
            border-radius: 4px;
            box-shadow: 0 0 10px #76ff03; /* Glow */
        }

        /* 4. TABLE HEADERS */
        .green-header { 
            color: #ffffff; background-color: #1b5e20; padding: 12px; border-radius: 6px; text-align: center; font-weight: bold; margin-bottom: 10px; border: 1px solid #2e7d32;
        }
        .red-header { 
            color: #ffffff; background-color: #b71c1c; padding: 12px; border-radius: 6px; text-align: center; font-weight: bold; margin-bottom: 10px; border: 1px solid #c62828;
        }
        
        /* 5. INFO BOXES */
        .info-box {
            background-color: #1a1c24;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            border-top: 4px solid #4facfe;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            height: 100%;
        }
        .info-icon { font-size: 30px; margin-bottom: 10px; display: block; }
        .info-title { font-weight: bold; font-size: 18px; color: white; margin-bottom: 5px; }
        .info-desc { color: #888; font-size: 13px; }
    </style>
""", unsafe_allow_html=True)

# --- 3. HEADER ---
st.markdown("""
    <div style="text-align: center; margin-bottom: 30px;">
        <h1 style="color: #ffffff; font-size: 3rem; margin-bottom: 0px; font-weight: 800;">
            🕵️‍♂️ Talent Finder
        </h1>
        <h3 style="color: #b0b0b0; font-size: 1.1rem; font-weight: 400; margin-top: 5px; letter-spacing: 1px; opacity: 0.8;">
            AI-Powered Resume Screening & Analysis System
        </h3>
    </div>
    <hr style="margin-top: 0; margin-bottom: 40px; opacity: 0.1; border-color: white;">
""", unsafe_allow_html=True)

tab1, tab2 = st.tabs(["🚀 Dashboard Scanner", "📂 Database & Reports"])

# ================== TAB 1: DYNAMIC DASHBOARD ==================
with tab1:
    col_up1, col_up2, col_up3 = st.columns([1, 6, 1])
    with col_up2:
        with st.container():
            c1, c2 = st.columns(2)
            jd = c1.file_uploader("1️⃣ Job Description (JD)", type=["pdf","docx","txt"])
            resumes = c2.file_uploader("2️⃣ Resumes (Bulk)", type=["pdf","docx","txt"], accept_multiple_files=True)
            
            st.markdown("<br>", unsafe_allow_html=True)
            if 'analyzed' not in st.session_state:
                st.session_state.analyzed = False

            analyze_btn = st.button("🚀 Analyze Candidates Now", type="primary", use_container_width=True)

    # --- SHOW RESULTS (If Analyzed) ---
    if analyze_btn and jd and resumes:
        st.session_state.analyzed = True
        
        st.markdown("<br>", unsafe_allow_html=True)
        with st.spinner("Processing Resumes..."):
            try:
                # 1. Extraction
                jd_text = extract_text(jd)
                resume_texts = [extract_text(r) for r in resumes]
                
                table_data = []
                for r, text in zip(resumes, resume_texts):
                    email = extract_details(text)
                    table_data.append({"Name": r.name, "Email": email})

                # 2. Matching
                scores_data = calculate_scores(jd_text, resume_texts)
                
                # 3. Merging
                final_rows = []
                for i, res in enumerate(scores_data):
                    row = table_data[i]
                    row["Score"] = round(res["score"] * 100, 1)
                    row["Missing Skills"] = ", ".join(res["missing"]) if res["missing"] else "None"
                    final_rows.append(row)
                    save_scan_result(jd.name, row['Name'], row['Email'], row['Score'])

                df = pd.DataFrame(final_rows)

                if not df.empty:
                    df = df.sort_values(by="Score", ascending=False)
                    
                    df_winners = df.iloc[:2] 
                    df_pass = df[df['Score'] > 50]
                    df_reject = df[df['Score'] <= 50]

                    # --- A. METRIC CARDS ---
                    m1, m2, m3 = st.columns(3)
                    m1.metric("🏆 Top Candidates", len(df_winners)) 
                    m2.metric("✅ Qualified", len(df_pass))
                    m3.metric("❌ Rejected", len(df_reject))

                    # --- B. WINNER BOX ---
                    winner_html_content = ""
                    for idx, row in df_winners.iterrows():
                        winner_html_content += f"""<div class="winner-item"><div class="winner-name">📄 {row['Name']}</div><div class="winner-email">📧 {row['Email']}</div><div class="winner-score">Match Score: {row['Score']}%</div><div class="progress-track"><div class="progress-fill" style="width:{row['Score']}%;"></div></div></div>"""
                    
                    st.markdown(f"""<div class="winner-box"><div class="winner-header">🚀 Top Recommended Candidates</div>{winner_html_content}</div>""", unsafe_allow_html=True)
                    
                    st.markdown("<br>", unsafe_allow_html=True)

                    # --- C. TABLES WITH PROGRESS BARS ---
                    col_left, col_right = st.columns(2)
                    with col_left:
                        st.markdown('<div class="green-header">✅ Shortlisted Candidates</div>', unsafe_allow_html=True)
                        if not df_pass.empty:
                            st.dataframe(
                                df_pass[["Name", "Email", "Score", "Missing Skills"]],
                                use_container_width=True,
                                hide_index=True,
                                column_config={
                                    "Score": st.column_config.ProgressColumn(
                                        "Match Score",
                                        format="%d%%",
                                        min_value=0,
                                        max_value=100,
                                    )
                                }
                            )
                        else:
                            st.info("No shortlisted candidates.")
                    with col_right:
                        st.markdown('<div class="red-header">❌ Rejected Candidates</div>', unsafe_allow_html=True)
                        if not df_reject.empty:
                            st.dataframe(
                                df_reject[["Name", "Email", "Score", "Missing Skills"]],
                                use_container_width=True,
                                hide_index=True,
                                column_config={
                                    "Score": st.column_config.ProgressColumn(
                                        "Match Score",
                                        format="%d%%",
                                        min_value=0,
                                        max_value=100,
                                    )
                                }
                            )
                        else:
                            st.success("No rejected candidates.")

            except Exception as e:
                st.error(f"Error: {e}")

    # --- SHOW INFO CARDS (If Not Analyzed) ---
    elif not analyze_btn: 
        st.markdown("<br><br>", unsafe_allow_html=True)
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("""
            <div class="info-box">
                <span class="info-icon">📂</span>
                <div class="info-title">1. Upload Data</div>
                <div class="info-desc">Upload Job Description (JD) and Candidate Resumes in PDF/DOCX.</div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown("""
            <div class="info-box">
                <span class="info-icon">🧠</span>
                <div class="info-title">2. AI Analysis</div>
                <div class="info-desc">Our AI Engine scans resumes against JD keywords for best matching.</div>
            </div>
            """, unsafe_allow_html=True)
        with col3:
            st.markdown("""
            <div class="info-box">
                <span class="info-icon">📊</span>
                <div class="info-title">3. Get Results</div>
                <div class="info-desc">Instant ranking, scoring, and detailed comparison reports.</div>
            </div>
            """, unsafe_allow_html=True)

# ================== TAB 2: AUDIT LOGS (Advanced) ==================
with tab2:
    st.markdown("### 📂 Database & Reports")
    
    df_history = fetch_history()
    
    if not df_history.empty:
        c1, c2 = st.columns([3, 1])
        with c1:
            st.info(f"💾 Total Records: {len(df_history)} | 💼 Jobs: {df_history['Job Description'].nunique()}")
        with c2:
            if st.button("🔥 Delete All Data", type="primary"):
                delete_all_records()
                st.rerun()

        st.divider()

        search_query = st.text_input("🔍 Search Job Role", placeholder="e.g. Python, Marketing...")
        unique_jobs = df_history['Job Description'].unique()
        if search_query:
            unique_jobs = [job for job in unique_jobs if search_query.lower() in job.lower()]

        for job in unique_jobs:
            job_df = df_history[df_history['Job Description'] == job]
            count = len(job_df)
            
            with st.expander(f"💼 {job} ({count} Candidates)", expanded=False):
                st.dataframe(
                    job_df,
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "Timestamp": st.column_config.DatetimeColumn("Date", format="D MMM YYYY, h:mm a"),
                        "Score": st.column_config.ProgressColumn("Score", format="%d%%", min_value=0, max_value=100)
                    }
                )
                
                col_csv, col_del = st.columns([1, 4])
                with col_csv:
                    csv = job_df.to_csv(index=False).encode('utf-8')
                    st.download_button(label="📥 CSV", data=csv, file_name=f"Report_{job}.csv", mime="text/csv")
                with col_del:
                    if st.button(f"🗑️ Delete History", key=f"del_{job}"):
                        ids_to_delete = job_df['id'].tolist()
                        delete_record(ids_to_delete)
                        st.success(f"Deleted history for {job}")
                        st.rerun()
    else:
        st.info("No history found yet.")