import numpy as np
from sentence_transformers import SentenceTransformer, util
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

try:
    model = SentenceTransformer('all-MiniLM-L6-v2')
except:
    model = None

# Skills Database (Lowercase mein rakhna zaroori hai match ke liye)
SKILL_DB = {
    "python", "java", "c++", "sql", "aws", "azure", "react", "node", "html", "css", 
    "javascript", "machine learning", "docker", "kubernetes", "git", "linux", "excel", 
    "tableau", "power bi", "django", "flask", "spring boot", "communication", "pandas", 
    "numpy", "scikit-learn", "tensorflow", "pytorch"
}

def extract_skills_from_text(text):
    found_skills = set()
    text_lower = text.lower()
    for skill in SKILL_DB:
        # Pura word match karega (e.g., 'java' dhoondhega, 'javascript' nahi)
        if re.search(r'\b' + re.escape(skill) + r'\b', text_lower):
            found_skills.add(skill)
    return found_skills

def calculate_scores(jd, resumes):
    valid_resumes = [r if r and r.strip() != "" else " " for r in resumes]
    if not valid_resumes:
        return []

    # 1. AI Score
    semantic_scores = [0] * len(valid_resumes)
    if model:
        try:
            jd_emb = model.encode(jd, convert_to_tensor=True)
            res_emb = model.encode(valid_resumes, convert_to_tensor=True)
            semantic_scores = util.cos_sim(jd_emb, res_emb)[0].tolist()
        except:
            pass

    # 2. Keyword Score
    keyword_scores = [0] * len(valid_resumes)
    try:
        vectorizer = CountVectorizer(stop_words='english')
        all_docs = [jd] + valid_resumes
        matrix = vectorizer.fit_transform(all_docs)
        keyword_scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten().tolist()
    except:
        pass

    # 3. Skill Gap Analysis
    jd_skills = extract_skills_from_text(jd)
    
    results = []
    for i, resume_text in enumerate(valid_resumes):
        ai_score = max(0, semantic_scores[i])
        kw_score = keyword_scores[i]
        final_score = (ai_score * 0.7) + (kw_score * 0.3)
        
        # Missing Skills nikalna
        resume_skills = extract_skills_from_text(resume_text)
        missing_skills = list(jd_skills - resume_skills)
        
        results.append({
            "score": final_score,
            "missing": missing_skills if missing_skills else ["None"]
        })

    return results
