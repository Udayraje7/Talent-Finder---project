
import pandas as pd

def build_dataframe(names, scores):
    return pd.DataFrame({
        "Resume": names,
        "Score": (scores * 10).round(2)
    })
