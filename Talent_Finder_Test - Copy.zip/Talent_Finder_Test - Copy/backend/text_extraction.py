import PyPDF2
import docx
import re

def extract_text(file):
    text = ""
    try:
        if file.name.endswith(".txt"):
            text = file.read().decode("utf-8")
        elif file.name.endswith(".pdf"):
            reader = PyPDF2.PdfReader(file)
            text_list = []
            for page in reader.pages:
                txt = page.extract_text()
                if txt:
                    text_list.append(txt)
            text = " ".join(text_list)
        elif file.name.endswith(".docx"):
            doc = docx.Document(file)
            text = "\n".join([para.text for para in doc.paragraphs])
    except Exception as e:
        return ""
    return text

def extract_details(text):
    # Email nikalne ka simple logic
    try:
        email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        match = re.search(email_pattern, text)
        return match.group(0) if match else "Not Found"
    except:
        return "Not Found"