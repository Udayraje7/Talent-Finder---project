import sqlite3
import datetime
import pandas as pd

DB_NAME = "talent_finder.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS history
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  job_description TEXT,
                  candidate_name TEXT,
                  email TEXT,
                  score REAL,
                  timestamp DATETIME)''')
    try:
        c.execute("ALTER TABLE history ADD COLUMN email TEXT")
    except:
        pass 
    conn.commit()
    conn.close()

def save_scan_result(jd_name, candidate_name, email, score):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id FROM history WHERE job_description = ? AND email = ?", (jd_name, email))
    data = c.fetchone()
    if data is None:
        c.execute("INSERT INTO history (job_description, candidate_name, email, score, timestamp) VALUES (?, ?, ?, ?, ?)",
                  (jd_name, candidate_name, email, score, datetime.datetime.now()))
        conn.commit()
    else:
        pass
    conn.close()

def fetch_history():
    conn = sqlite3.connect(DB_NAME)
    df = pd.read_sql_query("SELECT id, job_description as 'Job Description', candidate_name as 'Name', email as 'Email', score as 'Score', timestamp as 'Timestamp' FROM history ORDER BY timestamp DESC", conn)
    conn.close()
    return df

def delete_record(record_ids):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    for rid in record_ids:
        c.execute("DELETE FROM history WHERE id=?", (rid,))
    conn.commit()
    conn.close()

def delete_all_records():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("DELETE FROM history")
    conn.commit()
    conn.close()